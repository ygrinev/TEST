﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NUnit.Framework;

namespace CorityTest
{
    [TestFixture]
    class Tests
    {
        [Test]
        void EnsureFileExists()
        {
            
        }
        [Test]
        void ValidateInputData()
        {

        }
        [Test]
        void ValidateDataTerminator()
        {

        }
    }
}
