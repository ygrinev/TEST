﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HackerRank.Data
{
    class ArrayManipulationData
    {
        public static int[][] data = new int[][] {
            new int[] {29, 40, 787},
            new int[] {9, 26, 219},
            new int[] {21, 31, 214},
            new int[] {8, 22, 719},
            new int[] {15, 23, 102},
            new int[] {11, 24, 83},
            new int[] {14, 22, 321},
            new int[] {5, 22, 300},
            new int[] {11, 30, 832},
            new int[] {5, 25, 29},
            new int[] {16, 24, 577},
            new int[] {3, 10, 905},
            new int[] {15, 22, 335},
            new int[] {29, 35, 254},
            new int[] {9, 20, 20},
            new int[] {33, 34, 351},
            new int[] {30, 38, 564},
            new int[] {11, 31, 969},
            new int[] {3, 32, 11},
            new int[] {29, 35, 267},
            new int[] {4, 24, 531},
            new int[] {1, 38, 892},
            new int[] {12, 18, 825},
            new int[] {25, 32, 99},
            new int[] {3, 39, 107},
            new int[] {12, 37, 131},
            new int[] {3, 26, 640},
            new int[] {8, 39, 483},
            new int[] {8, 11, 194},
            new int[] {12, 37, 502}
        };
    }
}
