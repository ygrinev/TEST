﻿namespace HackerRank
{
    public class GraphData
    {
        public static int[][] data = new int[][]{
            new int[] {5,56},
            new int[] {4,51},
            new int[] {2,53},
            new int[] {8,52},
            new int[] {5,43},
            new int[] {2,80},
            new int[] {5,47},
            new int[] {4,79},
            new int[] {3,75},
            new int[] {1,67},
            new int[] {7,61},
            new int[] {2,57},
            new int[] {5,47},
            new int[] {4,63},
            new int[] {10,79},
            new int[] {1,57},
            new int[] {4,42},
            new int[] {8,79},
            new int[] {6,53},
            new int[] {3,74},
            new int[] {7,60},
            new int[] {10,79},
            new int[] {5,46},
            new int[] {3,50},
            new int[] {6,57},
            new int[] {8,71},
            new int[] {6,74},
            new int[] {10,44},
            new int[] {9,80},
            new int[] {7,59},
            new int[] {7,74},
            new int[] {6,55},
            new int[] {3,77},
            new int[] {3,53},
            new int[] {5,50},
            new int[] {9,70},
            new int[] {4,72},
            new int[] {5,73},
            new int[] {6,70},
            new int[] {7,46}
        };
    }
}
