﻿namespace HackerRank
{
    class MaxCostData
    {
        public static int[][] tree0 = new int[][]{
            new int[] {1, 2, 3},
            new int[] {1, 4, 2},
            new int[] {2, 5, 6},
            new int[] {3, 4, 1}
        };
        public static int[][] queries0 = new int[][]{
            new int[] {1, 1},
            new int[] {1, 2},
            new int[] {2, 3},
            new int[] {2, 5},
            new int[] {1, 6}
        };
    }
}
